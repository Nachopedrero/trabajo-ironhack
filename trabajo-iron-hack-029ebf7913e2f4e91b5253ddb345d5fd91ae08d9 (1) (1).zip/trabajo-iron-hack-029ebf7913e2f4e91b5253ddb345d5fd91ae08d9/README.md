# trabajo-iron-hack

El enlace al repositorio de GitHub de este proyecto es el siguiente: [GitHub](https://github.com/jzazooro/trabajo-iron-hack.git)

### Resumen

Para este proyecto hemos realizado varios modelos de regresion (lineal, logaritmica, neperiana y exponencial) con el fin de poder predecir el precio de cualquier casa en funcion de sus caracteristicas.

### Integrantes

- Jose Zazo
- Ignacio Guerrero
